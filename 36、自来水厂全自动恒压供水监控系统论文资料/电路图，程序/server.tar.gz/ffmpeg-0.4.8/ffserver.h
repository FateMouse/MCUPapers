#ifndef FFSERVER_H
#define FFSERVER_H

/* interface between ffserver and modules */

void ffserver_module_init(void);

#endif
